package in.kluniversity.HybernetInheritence;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	StandardServiceRegistry ssr= new StandardServiceRegistryBuilder().configure("hibernate.hbm.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
      
        SessionFactory factory = meta.getSessionFactoryBuilder().build();
        Session session = factory.openSession();  
        Transaction t;
        
       Patient p1=new Patient();
       InPatient p2=new InPatient();
       OutPatient p3 = new OutPatient();
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter 1 --> Add Patient , Enter 2 --> Add IN Patient , Enter 3 --> Add Out Patient");
      int k=sc.nextInt();
      if(k==1)
      {
    	  
    	  p1.setFn("Gella");
    	  p1.setLn("Abhiram");
    	 
    	  t=session.beginTransaction();
    	
    	  session.save(p1);
    	  t.commit();
    	  System.out.println("Patient Record Added");
      }
      else if(k==2)
      {
    	  p2.setFn("Avala");
    	  p2.setLn("Abhisheik");
    	  p2.setIntype("In");
    	  t=session.beginTransaction();
    	
    	  session.save(p2);
    	  t.commit();
    	  System.out.println("Patient Record Added");
      }
      else if(k==3)
      {
    	  p3.setFn("Rebba");
    	  p3.setLn("Pavan Sai");
    	  p3.setOutType("Out");
    	  t=session.beginTransaction();
    	
    	  session.save(p3);
    	  t.commit();
    	  System.out.println("Patient Record Added");
      }
    }
}
