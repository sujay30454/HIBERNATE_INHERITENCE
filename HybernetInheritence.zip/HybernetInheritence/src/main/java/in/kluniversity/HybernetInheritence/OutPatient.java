package in.kluniversity.HybernetInheritence;

import jakarta.persistence.Entity;

@Entity
public class OutPatient extends Patient {
   String OutType;

public String getOutType() {
	return OutType;
}

public void setOutType(String outType) {
	OutType = outType;
}
   
}
