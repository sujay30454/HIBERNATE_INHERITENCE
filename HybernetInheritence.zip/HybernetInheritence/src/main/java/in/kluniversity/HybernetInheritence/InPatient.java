package in.kluniversity.HybernetInheritence;

import jakarta.persistence.Entity;

@Entity
public class InPatient extends Patient {

	String Intype;

	public String getIntype() {
		return Intype;
	}

	public void setIntype(String intype) {
		Intype = intype;
	}

	
	
}
